package com.fixplot.factoriocore.content.combat;

import com.fixplot.factoriocore.content.electricity.ElectricPoleBlock;
import com.fixplot.factoriocore.content.fluids.BoilerBlock;
import com.fixplot.factoriocore.content.fluids.OffshorePumpBlock;
import com.fixplot.factoriocore.content.fluids.SteamEngineBlock;
import com.fixplot.factoriocore.content.logistics.belt.BeltBlock;
import com.fixplot.factoriocore.content.logistics.splitter.SplitterBlock;
import com.fixplot.factoriocore.content.oil.OilMachines;
import com.fixplot.factoriocore.content.production.assembler.AssemblerBlock;
import com.fixplot.factoriocore.content.production.burner_drill.BurnerDrillBlock;
import com.fixplot.factoriocore.content.production.electric_drill.ElectricDrillBlock;
import com.fixplot.factoriocore.content.production.furnace.FactorioFurnaceBlock;
import com.fixplot.factoriocore.content.research.LabBlock;
import com.fixplot.factoriocore.content.world.ore.ResourceOreBlock;
import com.fixplot.factoriocore.network.SyncBlockHealthPayload;
import com.fixplot.factoriocore.registry.ModBlocks;
import com.fixplot.factoriocore.registry.ModItems;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BlockHealthManager {

    private static final Map<RegistryKey<World>, Map<BlockPos, Integer>> SERVER_DAMAGE = new ConcurrentHashMap<>();
    private static final Map<BlockPos, Integer> CLIENT_DAMAGE = new ConcurrentHashMap<>();

    private static Map<BlockPos, Integer> getServerWorldMap(World world) {
        return SERVER_DAMAGE.computeIfAbsent(world.getRegistryKey(), k -> new ConcurrentHashMap<>());
    }

    public static int getMaxHealth(Block block) {
        if (block == ModBlocks.SMALL_ELECTRIC_POLE) return 100;
        if (block == ModBlocks.MEDIUM_ELECTRIC_POLE) return 100;
        if (block == ModBlocks.BIG_ELECTRIC_POLE) return 150;
        if (block == ModBlocks.SUBSTATION) return 200;
        if (block == ModBlocks.ELECTRIC_ENERGY_INTERFACE) return 150;
        if (block == ModBlocks.STONE_WALL) return 350;
        if (block == ModBlocks.GATE) return 350;
        if (block == ModBlocks.LAND_MINE) return 15;
        if (block == ModBlocks.WOODEN_CHEST) return 100;
        if (block == ModBlocks.IRON_CHEST) return 200;
        if (block == ModBlocks.STEEL_CHEST) return 350;
        if (block == ModBlocks.STORAGE_TANK) return 500;
        if (block == ModBlocks.SOLAR_PANEL) return 200;
        if (block == ModBlocks.ACCUMULATOR) return 150;

        if (block == ModBlocks.BURNER_INSERTER) return 100;
        if (block == ModBlocks.INSERTER) return 150;
        if (block == ModBlocks.LONG_HANDED_INSERTER) return 160;
        if (block == ModBlocks.FAST_INSERTER) return 160;

        if (block == ModBlocks.PIPE || block == ModBlocks.PIPE_TO_GROUND) return 100;
        if (block == ModBlocks.OFFSHORE_PUMP) return 150;
        if (block == ModBlocks.BOILER) return 200;
        if (block == ModBlocks.STEAM_ENGINE) return 400;
        if (block == ModBlocks.ELECTRIC_MINING_DRILL) return 300;
        if (block == ModBlocks.BURNER_MINING_DRILL) return 150;
        if (block == ModBlocks.STONE_FURNACE) return 200;
        if (block == ModBlocks.STEEL_FURNACE) return 300;
        if (block == ModBlocks.ASSEMBLER) return 300;
        if (block == ModBlocks.LAB) return 150;
        if (block == ModBlocks.PUMPJACK) return 250;
        if (block == ModBlocks.OIL_REFINERY) return 350;
        if (block == ModBlocks.CHEMICAL_PLANT) return 300;

        if (block instanceof SplitterBlock splitter) {
            return switch (splitter.getTier()) {
                case 2 -> 180;
                case 3 -> 190;
                default -> 170;
            };
        }
        if (block instanceof BeltBlock belt) {
            return switch (belt.getTier()) {
                case 2 -> 160;
                case 3 -> 170;
                default -> 150;
            };
        }
        return 0;
    }

    public static BlockPos getCanonicalPos(BlockPos pos, BlockState state) {
        Block block = state.getBlock();
        if (block instanceof ElectricPoleBlock) return ElectricPoleBlock.getMasterPos(pos, state);
        if (block instanceof OffshorePumpBlock) return OffshorePumpBlock.getMasterPos(pos, state);
        if (block instanceof BoilerBlock) return BoilerBlock.getMasterPos(pos, state);
        if (block instanceof SteamEngineBlock) return SteamEngineBlock.getMasterPos(pos, state);
        if (block instanceof ElectricDrillBlock) return ElectricDrillBlock.getMasterPos(pos, state);
        if (block instanceof AssemblerBlock) return AssemblerBlock.getMasterPos(pos, state);
        if (block instanceof LabBlock) return LabBlock.getMasterPos(pos, state);
        if (block instanceof OilMachines.OilRefineryBlock) return OilMachines.OilRefineryBlock.getMasterPos(pos, state);
        if (block instanceof OilMachines.Base3x3MachineBlock) return OilMachines.Base3x3MachineBlock.getMasterPos(pos, state);
        if (block instanceof BurnerDrillBlock) return BurnerDrillBlock.getMasterPos(pos, state);
        if (block instanceof FactorioFurnaceBlock) return FactorioFurnaceBlock.getMasterPos(pos, state);
        if (block instanceof com.fixplot.factoriocore.content.fluids.StorageTankBlock) return com.fixplot.factoriocore.content.fluids.StorageTankBlock.getMasterPos(pos, state);
        if (block instanceof com.fixplot.factoriocore.content.electricity.SolarAndAccumulatorMachines.SolarPanelBlock) return com.fixplot.factoriocore.content.electricity.SolarAndAccumulatorMachines.SolarPanelBlock.getMasterPos(pos, state);
        if (block instanceof com.fixplot.factoriocore.content.electricity.SolarAndAccumulatorMachines.AccumulatorBlock) return com.fixplot.factoriocore.content.electricity.SolarAndAccumulatorMachines.AccumulatorBlock.getMasterPos(pos, state);
        if (block instanceof SplitterBlock && state.contains(SplitterBlock.PART_RIGHT) && state.get(SplitterBlock.PART_RIGHT)) {
            Direction facing = state.get(BeltBlock.FACING);
            return pos.offset(facing.rotateYCounterclockwise());
        }
        return pos.toImmutable();
    }

    public static int getDamageTaken(World world, BlockPos pos, BlockState state) {
        if (world == null) return 0;
        BlockPos masterPos = getCanonicalPos(pos, state);
        Map<BlockPos, Integer> map = world.isClient ? CLIENT_DAMAGE : getServerWorldMap(world);
        return map.getOrDefault(masterPos, 0);
    }

    public static int getCurrentHealth(World world, BlockPos pos, BlockState state) {
        int max = getMaxHealth(state.getBlock());
        if (max <= 0) return 0;
        int dmg = getDamageTaken(world, pos, state);
        return Math.max(0, max - dmg);
    }

    public static Map<BlockPos, Integer> getClientDamagedBlocks() {
        return CLIENT_DAMAGE;
    }

    public static void setClientDamage(BlockPos masterPos, int damage) {
        if (damage <= 0) {
            CLIENT_DAMAGE.remove(masterPos);
        } else {
            CLIENT_DAMAGE.put(masterPos.toImmutable(), damage);
        }
    }

    public static void damageBlock(ServerWorld world, BlockPos pos, BlockState state, int amount) {
        int maxHp = getMaxHealth(state.getBlock());
        if (maxHp <= 0 || amount <= 0) return;

        BlockPos masterPos = getCanonicalPos(pos, state);
        Map<BlockPos, Integer> map = getServerWorldMap(world);
        int newDamage = map.getOrDefault(masterPos, 0) + amount;

        if (newDamage >= maxHp) {
            map.remove(masterPos);
            syncToClients(world, masterPos, 0);
            destroyFactorioStructure(world, masterPos, world.getBlockState(masterPos));
        } else {
            map.put(masterPos, newDamage);
            syncToClients(world, masterPos, newDamage);
            world.playSound(null, pos, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 0.35f, 1.5f);
            world.spawnParticles(ParticleTypes.CRIT, pos.getX() + 0.5, pos.getY() + 0.7, pos.getZ() + 0.5,
                    6, 0.25, 0.25, 0.25, 0.05);
        }
    }

    public static boolean repairBlock(ServerWorld world, BlockPos pos, BlockState state, int amount) {
        int maxHp = getMaxHealth(state.getBlock());
        if (maxHp <= 0) return false;

        BlockPos masterPos = getCanonicalPos(pos, state);
        Map<BlockPos, Integer> map = getServerWorldMap(world);
        int currentDamage = map.getOrDefault(masterPos, 0);
        if (currentDamage <= 0) {
            return false;
        }

        int newDamage = Math.max(0, currentDamage - amount);
        if (newDamage == 0) {
            map.remove(masterPos);
        } else {
            map.put(masterPos, newDamage);
        }

        syncToClients(world, masterPos, newDamage);
        world.playSound(null, pos, SoundEvents.BLOCK_IRON_TRAPDOOR_CLOSE, SoundCategory.BLOCKS, 0.6f, 1.8f);
        world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pos.getX() + 0.5, pos.getY() + 0.75, pos.getZ() + 0.5,
                8, 0.3, 0.3, 0.3, 0.02);
        return true;
    }

    private static void destroyFactorioStructure(ServerWorld world, BlockPos masterPos, BlockState masterState) {
        Block block = masterState.getBlock();

        if (block instanceof ElectricPoleBlock pole && pole.isFootprint2x2()) {
            for (int part = 0; part < 4; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = ElectricPoleBlock.getPartPos(masterPos, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof OffshorePumpBlock) {
            Direction facing = masterState.get(OffshorePumpBlock.FACING);
            for (int part = 0; part <= 1; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = OffshorePumpBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof BoilerBlock) {
            Direction facing = masterState.get(BoilerBlock.FACING);
            for (int part = 0; part < 6; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = BoilerBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof SteamEngineBlock) {
            Direction facing = masterState.get(SteamEngineBlock.FACING);
            for (int part = 0; part < 15; part++) {
                for (int layer = 0; layer <= 2; layer++) {
                    BlockPos p = SteamEngineBlock.getPartPos(masterPos, facing, part, layer);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof ElectricDrillBlock) {
            Direction facing = masterState.get(ElectricDrillBlock.FACING);
            for (int part = 0; part < 9; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = ElectricDrillBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof AssemblerBlock) {
            Direction facing = masterState.get(AssemblerBlock.FACING);
            for (int part = 0; part < 9; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = AssemblerBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof LabBlock) {
            Direction facing = masterState.get(LabBlock.FACING);
            for (int part = 0; part < 9; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = LabBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof OilMachines.OilRefineryBlock) {
            Direction facing = masterState.get(OilMachines.OilRefineryBlock.FACING);
            for (int part = 0; part < 25; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = OilMachines.OilRefineryBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof OilMachines.Base3x3MachineBlock) {
            Direction facing = masterState.get(OilMachines.Base3x3MachineBlock.FACING);
            for (int part = 0; part < 9; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = OilMachines.Base3x3MachineBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof BurnerDrillBlock) {
            Direction f = masterState.get(BurnerDrillBlock.FACING);
            for (int p = 0; p < 4; p++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos bp = BurnerDrillBlock.getPartPos(masterPos, f, p, u == 1);
                    if (world.getBlockState(bp).isOf(block)) {
                        world.breakBlock(bp, false);
                    }
                }
            }
        } else if (block instanceof FactorioFurnaceBlock) {
            Direction facing = masterState.get(FactorioFurnaceBlock.FACING);
            for (int part = 0; part < 4; part++) {
                for (int u = 0; u <= 1; u++) {
                    BlockPos p = FactorioFurnaceBlock.getPartPos(masterPos, facing, part, u == 1);
                    if (world.getBlockState(p).isOf(block)) {
                        world.breakBlock(p, false);
                    }
                }
            }
        } else if (block instanceof SplitterBlock) {
            Direction facing = masterState.get(BeltBlock.FACING);
            BlockPos rightPos = masterPos.offset(facing.rotateYClockwise());
            if (world.getBlockState(rightPos).isOf(block)) {
                world.breakBlock(rightPos, false);
            }
            world.breakBlock(masterPos, false);
        } else {
            world.breakBlock(masterPos, false);
        }
    }

    private static void syncToClients(ServerWorld world, BlockPos masterPos, int damage) {
        SyncBlockHealthPayload payload = new SyncBlockHealthPayload(masterPos, damage);
        for (ServerPlayerEntity player : PlayerLookup.world(world)) {
            ServerPlayNetworking.send(player, payload);
        }
    }

    public static void registerServer() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!world.isClient && world instanceof ServerWorld serverWorld) {
                Block block = state.getBlock();
                if (getMaxHealth(block) > 0) {
                    BlockPos masterPos = getCanonicalPos(pos, state);
                    getServerWorldMap(serverWorld).remove(masterPos);
                    syncToClients(serverWorld, masterPos, 0);
                }

                if (!player.isCreative() && !(block instanceof ResourceOreBlock) && !(block instanceof OilMachines.CrudeOilDepositBlock)) {
                    Identifier id = Registries.BLOCK.getId(block);
                    Item item = block.asItem();
                    if (id.getNamespace().equals("factoriocore") && item != Items.AIR) {
                        player.getInventory().offerOrDrop(new ItemStack(item, 1));
                    }
                }
            }
        });

        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            BlockState state = world.getBlockState(pos);
            Block block = state.getBlock();
            int maxHp = getMaxHealth(block);
            if (maxHp <= 0) {
                return ActionResult.PASS;
            }

            ItemStack held = player.getStackInHand(hand);
            boolean isWeapon = held.getItem() instanceof SwordItem
                    || held.getItem() instanceof TridentItem
                    || held.getItem() instanceof MaceItem;

            if (isWeapon && player.isSneaking()) {
                if (!world.isClient && world instanceof ServerWorld serverWorld) {
                    damageBlock(serverWorld, pos, state, 25);
                    int left = getCurrentHealth(world, pos, state);
                    player.sendMessage(Text.literal("HP: " + left + " / " + maxHp), true);
                }
                return ActionResult.SUCCESS;
            }

            return ActionResult.PASS;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            ItemStack stack = player.getStackInHand(hand);
            if (!stack.isOf(ModItems.REPAIR_PACK)) {
                return ActionResult.PASS;
            }

            BlockPos pos = hitResult.getBlockPos();
            BlockState state = world.getBlockState(pos);
            int maxHp = getMaxHealth(state.getBlock());
            if (maxHp <= 0) {
                return ActionResult.PASS;
            }

            int currentDamage = getDamageTaken(world, pos, state);
            if (currentDamage <= 0) {
                return ActionResult.SUCCESS;
            }

            if (!world.isClient && world instanceof ServerWorld serverWorld) {
                if (repairBlock(serverWorld, pos, state, 25)) {
                    if (!player.isCreative()) {
                        stack.damage(1, player, hand == Hand.MAIN_HAND
                                ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
                    }
                }
            }
            return ActionResult.SUCCESS;
        });
    }
}