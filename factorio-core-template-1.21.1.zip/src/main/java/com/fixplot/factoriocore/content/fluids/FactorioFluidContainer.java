package com.fixplot.factoriocore.content.fluids;

import com.fixplot.factoriocore.content.combat.BlockHealthManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public interface FactorioFluidContainer {

    enum FluidKind {
        NONE("Empty", 0xFF555555),
        WATER("Water", 0xFF2980B9),
        STEAM("Steam", 0xFFD5DBDB),
        CRUDE_OIL("Crude Oil", 0xFF1C1C22),
        HEAVY_OIL("Heavy Oil", 0xFFA93226),
        LIGHT_OIL("Light Oil", 0xFFD68910),
        PETROLEUM_GAS("Petroleum Gas", 0xFF8E44AD),
        LUBRICANT("Lubricant", 0xFF27AE60),
        SULFURIC_ACID("Sulfuric Acid", 0xFFD4AC0D);

        public final String displayName;
        public final int color;

        FluidKind(String displayName, int color) {
            this.displayName = displayName;
            this.color = color;
        }
    }

    FluidKind getFluidKind();
    int getFluidAmount();
    int getFluidCapacity();
    int getTemperatureC();
    boolean canAcceptFluid(FluidKind kind, Direction fromSide);
    int insertFluid(FluidKind kind, int maxAmount, int tempC, Direction fromSide);

    static int pushFluidToNeighbor(World world, BlockPos targetPos, Direction fromSide,
                                   FluidKind kind, int maxOffer, int tempC) {
        if (world == null || maxOffer <= 0 || kind == FluidKind.NONE) return 0;
        var state = world.getBlockState(targetPos);
        BlockPos canonical = BlockHealthManager.getCanonicalPos(targetPos, state);
        if (world.getBlockEntity(canonical) instanceof FactorioFluidContainer container) {
            if (container.canAcceptFluid(kind, fromSide)) {
                return container.insertFluid(kind, maxOffer, tempC, fromSide);
            }
        }
        return 0;
    }
}