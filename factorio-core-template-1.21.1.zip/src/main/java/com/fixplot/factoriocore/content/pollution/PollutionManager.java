package com.fixplot.factoriocore.content.pollution;

import com.fixplot.factoriocore.content.fluids.BoilerBlock;
import com.fixplot.factoriocore.content.fluids.BoilerBlockEntity;
import com.fixplot.factoriocore.content.oil.OilMachines;
import com.fixplot.factoriocore.content.production.assembler.AssemblerBlock;
import com.fixplot.factoriocore.content.production.assembler.AssemblerBlockEntity;
import com.fixplot.factoriocore.content.production.burner_drill.BurnerDrillBlock;
import com.fixplot.factoriocore.content.production.burner_drill.BurnerDrillBlockEntity;
import com.fixplot.factoriocore.content.production.electric_drill.ElectricDrillBlock;
import com.fixplot.factoriocore.content.production.electric_drill.ElectricDrillBlockEntity;
import com.fixplot.factoriocore.content.production.furnace.FactorioFurnaceBlock;
import com.fixplot.factoriocore.content.production.furnace.FactorioFurnaceBlockEntity;
import com.fixplot.factoriocore.network.SyncPollutionPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PollutionManager {

    public static final float MAX_CHUNK_POLLUTION = 500.0f;
    private static final float DIFFUSION_RATE = 0.06f;
    private static final float BASE_DISSIPATION = 0.05f;

    private static final Map<RegistryKey<World>, Map<Long, Float>> WORLD_POLLUTION = new ConcurrentHashMap<>();
    private static final Map<Long, Float> CLIENT_POLLUTION_CACHE = new ConcurrentHashMap<>();

    public static Map<Long, Float> getWorldMap(World world) {
        return WORLD_POLLUTION.computeIfAbsent(world.getRegistryKey(), k -> new ConcurrentHashMap<>());
    }

    public static void emitPollution(World world, BlockPos pos, float amount) {
        if (world == null || world.isClient() || amount <= 0.0f) return;
        long chunkKey = ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4);
        Map<Long, Float> map = getWorldMap(world);
        float current = map.getOrDefault(chunkKey, 0.0f);
        map.put(chunkKey, Math.min(MAX_CHUNK_POLLUTION, current + amount));
    }

    public static float getPollutionAt(World world, BlockPos pos) {
        long key = ChunkPos.toLong(pos.getX() >> 4, pos.getZ() >> 4);
        if (world.isClient()) {
            return CLIENT_POLLUTION_CACHE.getOrDefault(key, 0.0f);
        }
        return getWorldMap(world).getOrDefault(key, 0.0f);
    }

    public static float getClientChunkPollution(int chunkX, int chunkZ) {
        return CLIENT_POLLUTION_CACHE.getOrDefault(ChunkPos.toLong(chunkX, chunkZ), 0.0f);
    }

    /**
     * Вычисляет плавный коэффициент позеленения воды (0.0 .. 1.0)
     * с учётом диффузии загрязнения с берега на водную гладь озера.
     */
    public static float getClientWaterTintFactor(int blockX, int blockZ) {
        float fx = (blockX / 16.0f) - 0.5f;
        float fz = (blockZ / 16.0f) - 0.5f;
        int cx0 = MathHelper.floor(fx);
        int cz0 = MathHelper.floor(fz);
        float tx = fx - cx0;
        float tz = fz - cz0;

        float p00 = getEffectiveWaterPollution(cx0, cz0);
        float p10 = getEffectiveWaterPollution(cx0 + 1, cz0);
        float p01 = getEffectiveWaterPollution(cx0, cz0 + 1);
        float p11 = getEffectiveWaterPollution(cx0 + 1, cz0 + 1);

        float px0 = MathHelper.lerp(tx, p00, p10);
        float px1 = MathHelper.lerp(tx, p01, p11);
        float poll = MathHelper.lerp(tz, px0, px1);

        if (poll < 0.8f) return 0.0f;
        return MathHelper.clamp((poll - 0.8f) / 18.0f, 0.0f, 1.0f);
    }

    private static float getEffectiveWaterPollution(int cx, int cz) {
        float direct = getClientChunkPollution(cx, cz);
        float maxNeighbor = 0.0f;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                float np = getClientChunkPollution(cx + dx, cz + dz);
                float weight = (dx == 0 || dz == 0) ? 0.55f : 0.35f;
                maxNeighbor = Math.max(maxNeighbor, np * weight);
            }
        }
        return Math.max(direct, maxNeighbor);
    }

    public static Map<Long, Float> getClientCache() {
        return CLIENT_POLLUTION_CACHE;
    }

    public static void updateClientCache(Map<Long, Float> syncedMap) {
        CLIENT_POLLUTION_CACHE.clear();
        CLIENT_POLLUTION_CACHE.putAll(syncedMap);
    }

    public static void clearClientCache() {
        CLIENT_POLLUTION_CACHE.clear();
    }

    public static void tickServerWorld(ServerWorld world) {
        long time = world.getTime();

        if (time % 20 == 0) {
            for (ServerPlayerEntity player : world.getPlayers()) {
                scanAndEmitAroundPlayer(world, player.getBlockPos(), 36);
            }
        }

        if (time % 40 == 0) {
            stepDiffusionAndAbsorption(world);
        }

        if (time % 20 == 0) {
            Map<Long, Float> fullMap = getWorldMap(world);
            for (ServerPlayerEntity player : world.getPlayers()) {
                int pcx = player.getChunkPos().x;
                int pcz = player.getChunkPos().z;
                Map<Long, Float> nearby = new HashMap<>();

                for (int dx = -12; dx <= 12; dx++) {
                    for (int dz = -12; dz <= 12; dz++) {
                        long k = ChunkPos.toLong(pcx + dx, pcz + dz);
                        float val = fullMap.getOrDefault(k, 0.0f);
                        if (val >= 0.25f) {
                            nearby.put(k, val);
                        }
                    }
                }
                ServerPlayNetworking.send(player, new SyncPollutionPayload(nearby));
            }
        }
    }

    private static void scanAndEmitAroundPlayer(ServerWorld world, BlockPos center, int radius) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -6; dy <= 6; dy++) {
                    BlockPos pos = center.add(dx, dy, dz);
                    BlockState state = world.getBlockState(pos);
                    if (state.isAir()) continue;
                    Block block = state.getBlock();

                    if (block instanceof BurnerDrillBlock
                            && state.get(BurnerDrillBlock.PART) == 0
                            && !state.get(BurnerDrillBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof BurnerDrillBlockEntity drill && drill.isWorking()) {
                            emitPollution(world, pos, 0.70f);
                            spawnChimneySmoke(world, pos.getX() + 0.5, pos.getY() + 2.55, pos.getZ() + 0.5, 1);
                        }
                    } else if (block instanceof ElectricDrillBlock
                            && state.get(ElectricDrillBlock.PART) == 4
                            && !state.get(ElectricDrillBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof ElectricDrillBlockEntity edrill && edrill.isActivelyMining()) {
                            emitPollution(world, pos, 0.55f);
                        }
                    } else if (block instanceof FactorioFurnaceBlock furnaceBlock
                            && state.get(FactorioFurnaceBlock.PART) == 0
                            && !state.get(FactorioFurnaceBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof FactorioFurnaceBlockEntity furnace && furnace.isBurning()) {
                            float emission = (furnaceBlock.getTier() == 1) ? 0.40f : 0.75f;
                            emitPollution(world, pos, emission);
                            spawnChimneySmoke(world, pos.getX() + 0.5, pos.getY() + 2.6, pos.getZ() + 0.5, 1);
                        }
                    } else if (block instanceof BoilerBlock
                            && state.get(BoilerBlock.PART) == 1
                            && !state.get(BoilerBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof BoilerBlockEntity boiler && boiler.isBurning()) {
                            emitPollution(world, pos, 1.10f * boiler.getLoadRatio());
                            spawnChimneySmoke(world, pos.getX() + 0.5, pos.getY() + 2.6, pos.getZ() + 0.5, 2);
                        }
                    } else if (block instanceof AssemblerBlock
                            && state.get(AssemblerBlock.PART) == 4
                            && !state.get(AssemblerBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof AssemblerBlockEntity asm && asm.isWorking()) {
                            emitPollution(world, pos, 0.30f);
                        }
                    } else if (block instanceof OilMachines.PumpjackBlock
                            && state.get(OilMachines.PumpjackBlock.PART) == 4
                            && !state.get(OilMachines.PumpjackBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof OilMachines.PumpjackBlockEntity pj && pj.isWorking()) {
                            emitPollution(world, pos, 0.65f);
                        }
                    } else if (block instanceof OilMachines.OilRefineryBlock
                            && state.get(OilMachines.OilRefineryBlock.PART) == 12
                            && !state.get(OilMachines.OilRefineryBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof OilMachines.OilRefineryBlockEntity ref && ref.isWorking()) {
                            emitPollution(world, pos, 0.90f);
                            spawnChimneySmoke(world, pos.getX() + 0.5, pos.getY() + 2.75, pos.getZ() + 0.5, 2);
                        }
                    } else if (block instanceof OilMachines.ChemicalPlantBlock
                            && state.get(OilMachines.ChemicalPlantBlock.PART) == 4
                            && !state.get(OilMachines.ChemicalPlantBlock.UPPER)) {
                        if (world.getBlockEntity(pos) instanceof OilMachines.ChemicalPlantBlockEntity cp && cp.isWorking()) {
                            emitPollution(world, pos, 0.60f);
                            spawnChimneySmoke(world, pos.getX() + 0.5, pos.getY() + 2.25, pos.getZ() + 0.5, 1);
                        }
                    }
                }
            }
        }
    }

    private static void spawnChimneySmoke(ServerWorld world, double x, double y, double z, int count) {
        world.spawnParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, x, y, z, count, 0.08, 0.10, 0.08, 0.012);
    }

    private static void stepDiffusionAndAbsorption(ServerWorld world) {
        Map<Long, Float> map = getWorldMap(world);
        if (map.isEmpty()) return;

        Map<Long, Float> nextMap = new HashMap<>(map.size());

        for (Map.Entry<Long, Float> entry : map.entrySet()) {
            long key = entry.getKey();
            float val = entry.getValue();
            if (val < 0.15f) continue;

            int cx = ChunkPos.getPackedX(key);
            int cz = ChunkPos.getPackedZ(key);

            float absorbed = BASE_DISSIPATION;
            if (world.isChunkLoaded(cx, cz)) {
                absorbed += sampleChunkNatureAbsorption(world, cx, cz, val);
            }

            float remaining = Math.max(0.0f, val - absorbed);
            if (remaining <= 0.1f) continue;

            // Уже с 3.0 PU загрязнение начинает расползаться на соседние чанки (и окрашивать воду озёр!)
            if (remaining > 3.0f) {
                float spreadEach = remaining * DIFFUSION_RATE;
                float stayed = remaining - (spreadEach * 4.0f);
                nextMap.merge(key, stayed, Float::sum);

                long[] neighbors = {
                        ChunkPos.toLong(cx + 1, cz),
                        ChunkPos.toLong(cx - 1, cz),
                        ChunkPos.toLong(cx, cz + 1),
                        ChunkPos.toLong(cx, cz - 1)
                };
                for (long nk : neighbors) {
                    nextMap.merge(nk, spreadEach, (a, b) -> Math.min(MAX_CHUNK_POLLUTION, a + b));
                }
            } else {
                nextMap.merge(key, remaining, Float::sum);
            }
        }

        map.clear();
        for (Map.Entry<Long, Float> e : nextMap.entrySet()) {
            if (e.getValue() >= 0.15f) {
                map.put(e.getKey(), MathHelper.clamp(e.getValue(), 0.0f, MAX_CHUNK_POLLUTION));
            }
        }
    }

    private static float sampleChunkNatureAbsorption(ServerWorld world, int cx, int cz, float chunkPollution) {
        float bonusAbsorption = 0.0f;
        int startX = cx << 4;
        int startZ = cz << 4;

        for (int i = 0; i < 2; i++) {
            int rx = startX + world.random.nextInt(16);
            int rz = startZ + world.random.nextInt(16);
            int topY = world.getTopY(Heightmap.Type.MOTION_BLOCKING, rx, rz) - 1;
            if (topY <= world.getBottomY()) continue;

            BlockPos surfacePos = new BlockPos(rx, topY, rz);
            BlockState state = world.getBlockState(surfacePos);

            if (state.isIn(BlockTags.LEAVES)) {
                bonusAbsorption += 0.12f;
                if (chunkPollution > 160.0f && world.random.nextFloat() < 0.02f) {
                    world.breakBlock(surfacePos, false);
                }
            } else if (state.isOf(Blocks.GRASS_BLOCK)) {
                bonusAbsorption += 0.03f;
                if (chunkPollution > 200.0f && world.random.nextFloat() < 0.015f) {
                    BlockState withered = world.random.nextBoolean()
                            ? Blocks.COARSE_DIRT.getDefaultState()
                            : Blocks.PODZOL.getDefaultState();
                    world.setBlockState(surfacePos, withered, Block.NOTIFY_LISTENERS);
                }
            }
        }
        return bonusAbsorption;
    }
}