package com.fixplot.factoriocore.worldgen;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.File;
import java.nio.file.Path;
import java.util.Random;

public class NauvisConfig {

    public static NauvisConfig ACTIVE = new NauvisConfig();

    public long worldSeed = new Random().nextLong();

    // Настройки ресурсов (1.0f = 100%, диапазон 0.0f .. 2.5f)
    public float ironFreq = 1.0f, ironSize = 1.0f, ironRichness = 1.0f;
    public float copperFreq = 1.0f, copperSize = 1.0f, copperRichness = 1.0f;
    public float coalFreq = 1.0f, coalSize = 1.0f, coalRichness = 1.0f;
    public float stoneFreq = 1.0f, stoneSize = 1.0f, stoneRichness = 1.0f;
    public float oilFreq = 1.0f, oilSize = 1.0f, oilRichness = 1.0f;

    // Настройки ландшафта и климата
    public float waterCoverage = 1.0f;   // 0.0 = без воды, 1.0 = стандарт, 2.0 = много воды
    public float waterScale = 1.0f;      // Масштаб озёр (0.5 .. 2.0)
    public float cliffFreq = 1.0f;       // Частота скал (0.0 = без скал .. 2.0)
    public float cliffContinuity = 1.0f; // Непрерывность скал (0.25 .. 2.0)
    public float treeCoverage = 1.0f;    // Количество лесов (0.0 .. 2.0)
    public float boulderFreq = 1.0f;     // Количество валунов (0.0 .. 2.0)
    public float moistureBias = 0.0f;    // Сдвиг влажности (-0.5 = пустыня .. +0.5 = луга)
    public float auxBias = 0.0f;         // Сдвиг Aux (-0.5 = жёлтый песок .. +0.5 = красная пустыня)

    public static long seed(long salt) {
        long s = ACTIVE.worldSeed ^ salt;
        s = (s ^ (s >>> 30)) * 0xbf58476d1ce4e5b9L;
        s = (s ^ (s >>> 27)) * 0x94d049bb133111ebL;
        return s ^ (s >>> 31);
    }

    public void resetDefaults() {
        ironFreq = 1.0f; ironSize = 1.0f; ironRichness = 1.0f;
        copperFreq = 1.0f; copperSize = 1.0f; copperRichness = 1.0f;
        coalFreq = 1.0f; coalSize = 1.0f; coalRichness = 1.0f;
        stoneFreq = 1.0f; stoneSize = 1.0f; stoneRichness = 1.0f;
        oilFreq = 1.0f; oilSize = 1.0f; oilRichness = 1.0f;

        waterCoverage = 1.0f;
        waterScale = 1.0f;
        cliffFreq = 1.0f;
        cliffContinuity = 1.0f;
        treeCoverage = 1.0f;
        boulderFreq = 1.0f;
        moistureBias = 0.0f;
        auxBias = 0.0f;
    }

    public void randomizeSeed() {
        this.worldSeed = new Random().nextLong();
    }

    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putLong("WorldSeed", worldSeed);

        nbt.putFloat("IronFreq", ironFreq); nbt.putFloat("IronSize", ironSize); nbt.putFloat("IronRich", ironRichness);
        nbt.putFloat("CopperFreq", copperFreq); nbt.putFloat("CopperSize", copperSize); nbt.putFloat("CopperRich", copperRichness);
        nbt.putFloat("CoalFreq", coalFreq); nbt.putFloat("CoalSize", coalSize); nbt.putFloat("CoalRich", coalRichness);
        nbt.putFloat("StoneFreq", stoneFreq); nbt.putFloat("StoneSize", stoneSize); nbt.putFloat("StoneRich", stoneRichness);
        nbt.putFloat("OilFreq", oilFreq); nbt.putFloat("OilSize", oilSize); nbt.putFloat("OilRich", oilRichness);

        nbt.putFloat("WaterCoverage", waterCoverage);
        nbt.putFloat("WaterScale", waterScale);
        nbt.putFloat("CliffFreq", cliffFreq);
        nbt.putFloat("CliffContinuity", cliffContinuity);
        nbt.putFloat("TreeCoverage", treeCoverage);
        nbt.putFloat("BoulderFreq", boulderFreq);
        nbt.putFloat("MoistureBias", moistureBias);
        nbt.putFloat("AuxBias", auxBias);
        return nbt;
    }

    public void fromNbt(NbtCompound nbt) {
        if (nbt.contains("WorldSeed")) worldSeed = nbt.getLong("WorldSeed");

        if (nbt.contains("IronFreq")) ironFreq = nbt.getFloat("IronFreq");
        if (nbt.contains("IronSize")) ironSize = nbt.getFloat("IronSize");
        if (nbt.contains("IronRich")) ironRichness = nbt.getFloat("IronRich");

        if (nbt.contains("CopperFreq")) copperFreq = nbt.getFloat("CopperFreq");
        if (nbt.contains("CopperSize")) copperSize = nbt.getFloat("CopperSize");
        if (nbt.contains("CopperRich")) copperRichness = nbt.getFloat("CopperRich");

        if (nbt.contains("CoalFreq")) coalFreq = nbt.getFloat("CoalFreq");
        if (nbt.contains("CoalSize")) coalSize = nbt.getFloat("CoalSize");
        if (nbt.contains("CoalRich")) coalRichness = nbt.getFloat("CoalRich");

        if (nbt.contains("StoneFreq")) stoneFreq = nbt.getFloat("StoneFreq");
        if (nbt.contains("StoneSize")) stoneSize = nbt.getFloat("StoneSize");
        if (nbt.contains("StoneRich")) stoneRichness = nbt.getFloat("StoneRich");

        if (nbt.contains("OilFreq")) oilFreq = nbt.getFloat("OilFreq");
        if (nbt.contains("OilSize")) oilSize = nbt.getFloat("OilSize");
        if (nbt.contains("OilRich")) oilRichness = nbt.getFloat("OilRich");

        if (nbt.contains("WaterCoverage")) waterCoverage = nbt.getFloat("WaterCoverage");
        if (nbt.contains("WaterScale")) waterScale = nbt.getFloat("WaterCoverage");
        if (nbt.contains("WaterScale")) waterScale = nbt.getFloat("WaterScale");
        if (nbt.contains("CliffFreq")) cliffFreq = nbt.getFloat("CliffFreq");
        if (nbt.contains("CliffContinuity")) cliffContinuity = nbt.getFloat("CliffContinuity");
        if (nbt.contains("TreeCoverage")) treeCoverage = nbt.getFloat("TreeCoverage");
        if (nbt.contains("BoulderFreq")) boulderFreq = nbt.getFloat("BoulderFreq");
        if (nbt.contains("MoistureBias")) moistureBias = nbt.getFloat("MoistureBias");
        if (nbt.contains("AuxBias")) auxBias = nbt.getFloat("AuxBias");
    }

    public static void loadOrSaveForServer(MinecraftServer server, boolean newlyCreatedConfig, long fallbackMcSeed) {
        try {
            Path dataDir = server.getSavePath(WorldSavePath.ROOT).resolve("data");
            File file = dataDir.resolve("factoriocore_nauvis.nbt").toFile();
            if (file.exists() && !newlyCreatedConfig) {
                NbtCompound nbt = NbtIo.readCompressed(file.toPath(), NbtSizeTracker.ofUnlimitedBytes());
                ACTIVE.fromNbt(nbt);
            } else {
                ACTIVE.worldSeed = fallbackMcSeed;
                dataDir.toFile().mkdirs();
                NbtIo.writeCompressed(ACTIVE.toNbt(), file.toPath());
            }
        } catch (Exception ignored) {
            ACTIVE.worldSeed = fallbackMcSeed;
        }
    }
}