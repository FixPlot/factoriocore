package com.fixplot.factoriocore.client.worldgen;

import com.fixplot.factoriocore.worldgen.NauvisChunkGenerator;
import com.fixplot.factoriocore.worldgen.NauvisConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class NauvisCustomizeScreen extends Screen {

    public static boolean customConfigTouched = false;

    private static final int PANEL_W = 480;
    private static final int PANEL_H = 264;
    private static final int MAP_RES = 92;
    private static final int MAP_PX_SCALE = 2;
    private static final int MAP_SIZE_PX = MAP_RES * MAP_PX_SCALE; // 184x184

    private final Screen parent;
    private int currentTab = 0; // 0 = Ресурсы, 1 = Ландшафт и Климат
    private int mapZoom = 4;    // 1:1, 1:2, 1:4, 1:8
    private final int[] previewPixels = new int[MAP_RES * MAP_RES];
    private boolean mapDirty = true;

    private record SliderEntry(
            int tab,
            int ry,
            String labelKey,
            int labelColor,
            float min,
            float max,
            boolean isCenteredOffset,
            Supplier<Float> getter,
            Consumer<Float> setter
    ) {}

    private final List<SliderEntry> sliders = new ArrayList<>();
    private SliderEntry activeDraggingSlider = null;

    public NauvisCustomizeScreen(Screen parent) {
        super(Text.translatable("gui.factoriocore.nauvis.title"));
        this.parent = parent;
        customConfigTouched = true;
        initSliders();
        rebuildMapPreview();
    }

    private void initSliders() {
        sliders.clear();
        NauvisConfig cfg = NauvisConfig.ACTIVE;

        // === ВКЛАДКА 0: РЕСУРСЫ (15 ползунков с шагом 12px: Железо, Медь, Уголь, Камень, Нефть) ===
        int ry = 5;
        int step = 12;

        // 1. Железная руда (#5B9BD5)
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.iron_freq", 0xFF5B9BD5, 0.0f, 2.5f, false, () -> cfg.ironFreq, v -> cfg.ironFreq = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.iron_size", 0xFF5B9BD5, 0.0f, 2.5f, false, () -> cfg.ironSize, v -> cfg.ironSize = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.iron_rich", 0xFF5B9BD5, 0.1f, 2.5f, false, () -> cfg.ironRichness, v -> cfg.ironRichness = v)); ry += step + 1;

        // 2. Медная руда (#ED7D31)
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.copper_freq", 0xFFED7D31, 0.0f, 2.5f, false, () -> cfg.copperFreq, v -> cfg.copperFreq = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.copper_size", 0xFFED7D31, 0.0f, 2.5f, false, () -> cfg.copperSize, v -> cfg.copperSize = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.copper_rich", 0xFFED7D31, 0.1f, 2.5f, false, () -> cfg.copperRichness, v -> cfg.copperRichness = v)); ry += step + 1;

        // 3. Уголь (#999B9F)
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.coal_freq", 0xFF999B9F, 0.0f, 2.5f, false, () -> cfg.coalFreq, v -> cfg.coalFreq = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.coal_size", 0xFF999B9F, 0.0f, 2.5f, false, () -> cfg.coalSize, v -> cfg.coalSize = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.coal_rich", 0xFF999B9F, 0.1f, 2.5f, false, () -> cfg.coalRichness, v -> cfg.coalRichness = v)); ry += step + 1;

        // 4. Камень (#D2C290)
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.stone_freq", 0xFFD2C290, 0.0f, 2.5f, false, () -> cfg.stoneFreq, v -> cfg.stoneFreq = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.stone_size", 0xFFD2C290, 0.0f, 2.5f, false, () -> cfg.stoneSize, v -> cfg.stoneSize = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.stone_rich", 0xFFD2C290, 0.1f, 2.5f, false, () -> cfg.stoneRichness, v -> cfg.stoneRichness = v)); ry += step + 1;

        // 5. Сырая нефть (#EC407A / #D81B60)
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.oil_freq", 0xFFEC407A, 0.0f, 2.5f, false, () -> cfg.oilFreq, v -> cfg.oilFreq = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.oil_size", 0xFFEC407A, 0.0f, 2.5f, false, () -> cfg.oilSize, v -> cfg.oilSize = v)); ry += step;
        sliders.add(new SliderEntry(0, ry, "nauvis.factoriocore.oil_rich", 0xFFEC407A, 0.1f, 2.5f, false, () -> cfg.oilRichness, v -> cfg.oilRichness = v));

        // === ВКЛАДКА 1: ЛАНДШАФТ И КЛИМАТ ===
        int ty = 10;
        int tStep = 22;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.water_cov", 0xFF4FC3F7, 0.0f, 2.0f, false, () -> cfg.waterCoverage, v -> cfg.waterCoverage = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.water_scale", 0xFF4FC3F7, 0.5f, 2.0f, false, () -> cfg.waterScale, v -> cfg.waterScale = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.cliff_freq", 0xFFB0BEC5, 0.0f, 2.0f, false, () -> cfg.cliffFreq, v -> cfg.cliffFreq = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.cliff_cont", 0xFFB0BEC5, 0.25f, 2.0f, false, () -> cfg.cliffContinuity, v -> cfg.cliffContinuity = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.tree_cov", 0xFF81C784, 0.0f, 2.0f, false, () -> cfg.treeCoverage, v -> cfg.treeCoverage = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.boulder_freq", 0xFFBCAAA4, 0.0f, 2.0f, false, () -> cfg.boulderFreq, v -> cfg.boulderFreq = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.moisture", 0xFF66BB6A, -0.5f, 0.5f, true, () -> cfg.moistureBias, v -> cfg.moistureBias = v)); ty += tStep;
        sliders.add(new SliderEntry(1, ty, "nauvis.factoriocore.temperature", 0xFFFFB74D, -0.5f, 0.5f, true, () -> cfg.auxBias, v -> cfg.auxBias = v));
    }

    private void rebuildMapPreview() {
        int half = MAP_RES / 2;
        for (int gz = 0; gz < MAP_RES; gz++) {
            int wz = (gz - half) * this.mapZoom;
            int rowOff = gz * MAP_RES;
            for (int gx = 0; gx < MAP_RES; gx++) {
                int wx = (gx - half) * this.mapZoom;
                previewPixels[rowOff + gx] = samplePreviewColorAt(wx, wz, this.mapZoom);
            }
        }
        this.mapDirty = false;
    }

    private static int samplePreviewColorAt(int wx, int wz, int zoom) {
        double elev = NauvisChunkGenerator.evaluateElevation(wx, wz);
        if (elev < 0.0) {
            return (elev > -0.09) ? 0xFF2874A6 : 0xFF1B4F72;
        }

        // 1. Проверяем месторождения сырой нефти с учётом масштаба карты предпросмотра
        if (NauvisChunkGenerator.hasCrudeOilPreviewAt(wx, wz, elev, Math.max(1, zoom))) {
            return 0xFFD81B60; // Ярко-пурпурный цвет нефти Factorio
        }

        // 2. Проверяем рудные пятна
        NauvisChunkGenerator.OreSample ore = NauvisChunkGenerator.sampleOreAt(wx, wz, elev);
        if (ore != null) {
            return switch (ore.oreType()) {
                case 0 -> 0xFF5B9BD5; // Iron
                case 1 -> 0xFFED7D31; // Copper
                case 2 -> 0xFF1C1C1E; // Coal
                default -> 0xFFD2C290; // Stone
            };
        }

        // 3. Скалы и леса
        if (NauvisChunkGenerator.evaluateCliffHeight(wx, wz, elev) > 0) {
            return 0xFF566573;
        }
        if (NauvisChunkGenerator.hasForestAt(wx, wz, elev)) {
            return 0xFF1E5622;
        }

        // 4. Биомы поверхности
        return switch (NauvisChunkGenerator.getBiomeAt(wx, wz)) {
            case LUSH_GRASS -> 0xFF3E6B2C;
            case DRY_GRASS -> 0xFF527532;
            case DRY_DIRT -> 0xFF7E5A3B;
            case SAND_DESERT -> 0xFFC2A661;
            case RED_DESERT -> 0xFF9C5238;
        };
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        if (this.mapDirty) {
            rebuildMapPreview();
        }

        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;

        // Внешний корпус окна
        context.fill(x, y, x + PANEL_W, y + PANEL_H, 0xFF111214);
        context.fill(x + 1, y + 1, x + PANEL_W - 1, y + PANEL_H - 1, 0xFF2D2E32);

        // Верхняя шапка с ребристыми полосками
        context.fill(x + 3, y + 3, x + PANEL_W - 3, y + 17, 0xFF222326);
        context.drawText(this.textRenderer, this.title, x + 8, y + 6, 0xFFFFCC66, true);
        int startRibs = x + 14 + this.textRenderer.getWidth(this.title);
        for (int rx = startRibs; rx < x + PANEL_W - 8; rx += 3) {
            context.fill(rx, y + 5, rx + 1, y + 14, 0xFF17181A);
        }

        // Строка зерна мира (Seed) + кнопки Random и Reset
        int seedY = y + 21;
        context.fill(x + 6, seedY, x + 190, seedY + 16, 0xFF141517);
        String seedStr = Text.translatable("gui.factoriocore.nauvis.seed", String.valueOf(NauvisConfig.ACTIVE.worldSeed)).getString();
        context.drawText(this.textRenderer, this.textRenderer.trimToWidth(seedStr, 178), x + 10, seedY + 4, 0xFFE6E6E6, false);

        drawButton(context, x + 194, seedY, 44, 16, Text.translatable("gui.factoriocore.nauvis.random").getString(), mouseX, mouseY, false);
        drawButton(context, x + 240, seedY, 42, 16, Text.translatable("gui.factoriocore.nauvis.reset").getString(), mouseX, mouseY, false);

        // Вкладки "Ресурсы" и "Ландшафт и Климат"
        int tabY = y + 40;
        drawTab(context, x + 6, tabY, 136, 15, Text.translatable("gui.factoriocore.nauvis.tab.resources").getString(), mouseX, mouseY, currentTab == 0);
        drawTab(context, x + 144, tabY, 138, 15, Text.translatable("gui.factoriocore.nauvis.tab.terrain").getString(), mouseX, mouseY, currentTab == 1);

        // Левая панель ползунков
        int leftX = x + 6;
        int leftY = y + 56;
        int leftW = 276;
        int leftH = PANEL_H - 62;
        context.fill(leftX, leftY, leftX + leftW, leftY + leftH, 0xFF17181A);
        context.fill(leftX + 1, leftY + 1, leftX + leftW - 1, leftY + leftH - 1, 0xFF232427);

        for (SliderEntry s : sliders) {
            if (s.tab != this.currentTab) continue;
            drawCompactSliderRow(context, leftX + 6, leftY + s.ry, leftW - 12, s);
        }

        // Правая панель: Карта предпросмотра Наувиса
        int mapFrameX = x + PANEL_W - MAP_SIZE_PX - 10;
        int mapFrameY = y + 21;
        context.fill(mapFrameX - 2, mapFrameY - 2, mapFrameX + MAP_SIZE_PX + 2, mapFrameY + MAP_SIZE_PX + 2, 0xFF141414);

        for (int gz = 0; gz < MAP_RES; gz++) {
            int py = mapFrameY + gz * MAP_PX_SCALE;
            int rowOff = gz * MAP_RES;
            for (int gx = 0; gx < MAP_RES; gx++) {
                int px = mapFrameX + gx * MAP_PX_SCALE;
                context.fill(px, py, px + MAP_PX_SCALE, py + MAP_PX_SCALE, previewPixels[rowOff + gx]);
            }
        }

        // Красный крестик точки спавна (0, 0) в центре карты
        int cx = mapFrameX + MAP_SIZE_PX / 2;
        int cy = mapFrameY + MAP_SIZE_PX / 2;
        context.fill(cx - 3, cy, cx + 4, cy + 1, 0xFFFF3333);
        context.fill(cx, cy - 3, cx + 1, cy + 4, 0xFFFF3333);

        // Плашка масштаба в левом верхнем углу карты (клик меняет масштаб 1:2 / 1:4 / 1:8)
        String zoomStr = Text.translatable("gui.factoriocore.nauvis.zoom", String.valueOf(this.mapZoom)).getString();
        int zw = this.textRenderer.getWidth(zoomStr) + 8;
        context.fill(mapFrameX + 3, mapFrameY + 3, mapFrameX + 3 + zw, mapFrameY + 15, 0xCC141414);
        context.drawText(this.textRenderer, zoomStr, mapFrameX + 7, mapFrameY + 5, 0xFFE6E6E6, false);

        // Легенда ресурсов под картой (Железо, Медь, Уголь, Камень, Нефть)
        int legY = mapFrameY + MAP_SIZE_PX + 5;
        int lx = mapFrameX;
        lx = drawLegendItem(context, lx, legY, 0xFF5B9BD5, Text.translatable("gui.factoriocore.nauvis.iron_short").getString());
        lx = drawLegendItem(context, lx, legY, 0xFFED7D31, Text.translatable("gui.factoriocore.nauvis.copper_short").getString());
        lx = drawLegendItem(context, lx, legY, 0xFF1C1C1E, Text.translatable("gui.factoriocore.nauvis.coal_short").getString());
        lx = drawLegendItem(context, lx, legY, 0xFFD2C290, Text.translatable("gui.factoriocore.nauvis.stone_short").getString());
        drawLegendItem(context, lx, legY, 0xFFD81B60, Text.translatableWithFallback("gui.factoriocore.nauvis.oil_short", "Oil").getString());

        // Кнопка "Применить и вернуться"
        int doneW = 116;
        int doneX = x + PANEL_W - doneW - 8;
        int doneY = y + PANEL_H - 24;
        drawButton(context, doneX, doneY, doneW, 18, Text.translatable("gui.factoriocore.nauvis.done").getString(), mouseX, mouseY, true);
    }

    private void drawCompactSliderRow(DrawContext context, int rx, int ry, int rw, SliderEntry s) {
        String label = Text.translatableWithFallback(s.labelKey, s.labelKey).getString();
        context.getMatrices().push();
        context.getMatrices().translate(rx, ry + 1, 0.0f);
        context.getMatrices().scale(0.82f, 0.82f, 1.0f);
        context.drawText(this.textRenderer, label, 0, 0, s.labelColor, false);
        context.getMatrices().pop();

        int trackX = rx + 158;
        int trackW = 68;
        int trackY = ry + 3;
        context.fill(trackX, trackY, trackX + trackW, trackY + 3, 0xFF121314);

        float val = s.getter.get();
        float ratio = MathHelper.clamp((val - s.min) / (s.max - s.min), 0.0f, 1.0f);
        int knobX = trackX + Math.round(ratio * (trackW - 4));
        context.fill(knobX, trackY - 2, knobX + 4, trackY + 5, 0xFFE59524);

        int pct = s.isCenteredOffset ? Math.round((1.0f + val * 2.0f) * 100.0f) : Math.round(val * 100.0f);
        String pctStr = pct + "%";
        context.getMatrices().push();
        context.getMatrices().translate(trackX + trackW + 5, ry + 1, 0.0f);
        context.getMatrices().scale(0.82f, 0.82f, 1.0f);
        context.drawText(this.textRenderer, pctStr, 0, 0, 0xFFE6E6E6, false);
        context.getMatrices().pop();
    }

    private int drawLegendItem(DrawContext context, int lx, int ly, int color, String name) {
        context.fill(lx, ly + 1, lx + 6, ly + 7, 0xFF111111);
        context.fill(lx + 1, ly + 2, lx + 5, ly + 6, color);
        context.getMatrices().push();
        context.getMatrices().translate(lx + 8, ly + 1, 0.0f);
        context.getMatrices().scale(0.78f, 0.78f, 1.0f);
        context.drawText(this.textRenderer, name, 0, 0, 0xFFDDDDDD, false);
        context.getMatrices().pop();
        return lx + 12 + Math.round(this.textRenderer.getWidth(name) * 0.78f);
    }

    private void drawTab(DrawContext context, int bx, int by, int bw, int bh, String label, int mx, int my, boolean active) {
        boolean hov = mx >= bx && mx <= bx + bw && my >= by && my <= by + bh;
        int bg = active ? 0xFFD4881E : (hov ? 0xFF44464A : 0xFF323438);
        context.fill(bx, by, bx + bw, by + bh, 0xFF141414);
        context.fill(bx + 1, by + 1, bx + bw - 1, by + bh - 1, bg);
        int tw = this.textRenderer.getWidth(label);
        context.drawText(this.textRenderer, label, bx + (bw - tw) / 2, by + 4, active ? 0xFF141414 : 0xFFE6E6E6, false);
    }

    private void drawButton(DrawContext context, int bx, int by, int bw, int bh, String label, int mx, int my, boolean orange) {
        boolean hov = mx >= bx && mx <= bx + bw && my >= by && my <= by + bh;
        int bg = orange ? (hov ? 0xFFE59524 : 0xFFD4881E) : (hov ? 0xFF4A4C50 : 0xFF36383C);
        context.fill(bx, by, bx + bw, by + bh, 0xFF141414);
        context.fill(bx + 1, by + 1, bx + bw - 1, by + bh - 1, bg);
        int tw = this.textRenderer.getWidth(label);
        context.drawText(this.textRenderer, label, bx + (bw - tw) / 2, by + (bh - 8) / 2, orange ? 0xFF141414 : 0xFFE6E6E6, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;

        // Random Seed
        if (mouseX >= x + 194 && mouseX <= x + 238 && mouseY >= y + 21 && mouseY <= y + 37) {
            NauvisConfig.ACTIVE.randomizeSeed();
            this.mapDirty = true;
            playClick();
            return true;
        }
        // Reset Defaults
        if (mouseX >= x + 240 && mouseX <= x + 282 && mouseY >= y + 21 && mouseY <= y + 37) {
            NauvisConfig.ACTIVE.resetDefaults();
            this.mapDirty = true;
            playClick();
            return true;
        }

        // Переключение вкладок
        if (mouseY >= y + 40 && mouseY <= y + 55) {
            if (mouseX >= x + 6 && mouseX <= x + 142) {
                this.currentTab = 0;
                playClick();
                return true;
            }
            if (mouseX >= x + 144 && mouseX <= x + 282) {
                this.currentTab = 1;
                playClick();
                return true;
            }
        }

        // Клик по ползункам
        int leftX = x + 6;
        int leftY = y + 56;
        int trackX = leftX + 6 + 158;
        int trackW = 68;
        for (SliderEntry s : sliders) {
            if (s.tab != this.currentTab) continue;
            int sy = leftY + s.ry;
            if (mouseX >= trackX - 4 && mouseX <= trackX + trackW + 4 && mouseY >= sy - 1 && mouseY <= sy + 10) {
                this.activeDraggingSlider = s;
                updateSliderFromMouse(s, mouseX, trackX, trackW);
                return true;
            }
        }

        // Клик по карте предпросмотра для переключения масштаба (1:2 -> 1:4 -> 1:8)
        int mapFrameX = x + PANEL_W - MAP_SIZE_PX - 10;
        int mapFrameY = y + 21;
        if (mouseX >= mapFrameX && mouseX <= mapFrameX + MAP_SIZE_PX && mouseY >= mapFrameY && mouseY <= mapFrameY + MAP_SIZE_PX) {
            this.mapZoom = (this.mapZoom == 2) ? 4 : (this.mapZoom == 4 ? 8 : 2);
            this.mapDirty = true;
            playClick();
            return true;
        }

        // Кнопка Apply & Done
        int doneW = 116;
        int doneX = x + PANEL_W - doneW - 8;
        int doneY = y + PANEL_H - 24;
        if (mouseX >= doneX && mouseX <= doneX + doneW && mouseY >= doneY && mouseY <= doneY + 18) {
            playClick();
            if (this.client != null) {
                this.client.setScreen(this.parent);
            }
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void updateSliderFromMouse(SliderEntry s, double mouseX, int trackX, int trackW) {
        float ratio = MathHelper.clamp((float) (mouseX - trackX) / (float) trackW, 0.0f, 1.0f);
        float raw = s.min + ratio * (s.max - s.min);
        float stepped = Math.round(raw * 20.0f) / 20.0f;
        s.setter.accept(stepped);
        this.mapDirty = true;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (this.activeDraggingSlider != null) {
            int x = (this.width - PANEL_W) / 2;
            int trackX = x + 12 + 158;
            updateSliderFromMouse(this.activeDraggingSlider, mouseX, trackX, 68);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        this.activeDraggingSlider = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int x = (this.width - PANEL_W) / 2;
        int y = (this.height - PANEL_H) / 2;
        int mapFrameX = x + PANEL_W - MAP_SIZE_PX - 10;
        int mapFrameY = y + 21;
        if (mouseX >= mapFrameX && mouseX <= mapFrameX + MAP_SIZE_PX && mouseY >= mapFrameY && mouseY <= mapFrameY + MAP_SIZE_PX) {
            if (verticalAmount > 0 && this.mapZoom > 1) {
                this.mapZoom /= 2;
                this.mapDirty = true;
            } else if (verticalAmount < 0 && this.mapZoom < 8) {
                this.mapZoom *= 2;
                this.mapDirty = true;
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void playClick() {
        if (this.client != null && this.client.player != null) {
            this.client.player.playSound(SoundEvents.UI_BUTTON_CLICK.value(), 0.35f, 1.2f);
        }
    }
}