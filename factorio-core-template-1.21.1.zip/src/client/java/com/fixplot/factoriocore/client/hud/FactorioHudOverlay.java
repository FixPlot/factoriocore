package com.fixplot.factoriocore.client.hud;

import com.fixplot.factoriocore.client.content.crafting.ClientCraftingQueueHud;
import com.fixplot.factoriocore.client.content.pollution.PollutionClientRenderer;
import com.fixplot.factoriocore.config.FactorioConfig;
import com.fixplot.factoriocore.content.combat.BlockHealthManager;
import com.fixplot.factoriocore.content.electricity.PowerNetworkManager;
import com.fixplot.factoriocore.content.fluids.*;
import com.fixplot.factoriocore.content.logistics.belt.BeltBlock;
import com.fixplot.factoriocore.content.logistics.burner_inserter.BurnerInserterBlock;
import com.fixplot.factoriocore.content.logistics.chest.FactorioChestBlock;
import com.fixplot.factoriocore.content.logistics.chest.FactorioChestBlockEntity;
import com.fixplot.factoriocore.content.logistics.inserter.InserterBlock;
import com.fixplot.factoriocore.content.logistics.inserter.InserterBlockEntity;
import com.fixplot.factoriocore.content.logistics.pavement.PavementBlock;
import com.fixplot.factoriocore.content.oil.OilMachines;
import com.fixplot.factoriocore.content.production.assembler.AssemblerBlockEntity;
import com.fixplot.factoriocore.content.production.burner_drill.BurnerDrillBlockEntity;
import com.fixplot.factoriocore.content.production.electric_drill.ElectricDrillBlock;
import com.fixplot.factoriocore.content.production.electric_drill.ElectricDrillBlockEntity;
import com.fixplot.factoriocore.content.production.furnace.FactorioFurnaceBlock;
import com.fixplot.factoriocore.content.production.furnace.FactorioFurnaceBlockEntity;
import com.fixplot.factoriocore.content.research.ResearchManager;
import com.fixplot.factoriocore.content.world.ore.ResourceOreBlock;
import com.fixplot.factoriocore.content.world.ore.ResourceOreBlockEntity;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FactorioHudOverlay {

    private static final int MAP_CELLS = 44;
    private static final int PIXEL_SCALE = 2;
    private static final int MAP_SIZE_PX = MAP_CELLS * PIXEL_SCALE;

    private static final int[] colorBuffer = new int[MAP_CELLS * MAP_CELLS];
    private static boolean minimapVisible = true;
    private static int blocksPerCell = 1;
    private static int nextSliceRow = 0;

    private static float prevMiningProgress = 0.0f;
    private static float miningBarProgress = 0.0f;
    private static BlockPos lastMiningPos = null;
    private static int lastSeenOreAmount = -1;

    private record RadarBlip(int offsetX, int offsetZ, int color) {}
    private static final List<RadarBlip> cachedRadarBlips = new ArrayList<>();

    private static KeyBinding toggleMapKey;
    private static KeyBinding zoomInKey;
    private static KeyBinding zoomOutKey;

    public static KeyBinding getToggleMapKey() { return toggleMapKey; }
    public static KeyBinding getZoomInKey() { return zoomInKey; }
    public static KeyBinding getZoomOutKey() { return zoomOutKey; }

    public static void register() {
        toggleMapKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.factoriocore.toggle_minimap", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.factoriocore"));
        zoomInKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.factoriocore.minimap_zoom_in", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL, "category.factoriocore"));
        zoomOutKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.factoriocore.minimap_zoom_out", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_MINUS, "category.factoriocore"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleMapKey.wasPressed()) minimapVisible = !minimapVisible;
            while (zoomInKey.wasPressed()) if (blocksPerCell > 1) blocksPerCell /= 2;
            while (zoomOutKey.wasPressed()) if (blocksPerCell < 4) blocksPerCell *= 2;

            if (client.world != null && client.player != null && !client.isPaused()) {
                if (minimapVisible && FactorioConfig.INSTANCE.enableMinimap) {
                    updateMapSlice(client.world, client.player, nextSliceRow, nextSliceRow + 11);
                    nextSliceRow = (nextSliceRow + 11) % MAP_CELLS;
                    if ((client.world.getTime() & 7L) == 0L) updateRadarEntities(client.world, client.player);
                }
                tickMiningProgressBar(client);
            }
        });

        HudRenderCallback.EVENT.register(FactorioHudOverlay::renderHud);
    }

    private static void tickMiningProgressBar(MinecraftClient client) {
        if (client.player == null || client.world == null || client.player.isCreative() || client.interactionManager == null) {
            prevMiningProgress = 0.0f;
            miningBarProgress = 0.0f;
            lastMiningPos = null;
            return;
        }

        if (client.options.attackKey.isPressed() && client.interactionManager.isBreakingBlock()
                && client.crosshairTarget instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            BlockPos pos = hit.getBlockPos();
            BlockState state = client.world.getBlockState(pos);
            Block block = state.getBlock();

            if (BlockHealthManager.getMaxHealth(block) > 0 || block instanceof ResourceOreBlock || block instanceof PavementBlock) {
                int currentOre = -1;
                if (block instanceof ResourceOreBlock && client.world.getBlockEntity(pos) instanceof ResourceOreBlockEntity oreBe) {
                    currentOre = oreBe.getOrInitAmount();
                }

                if (!pos.equals(lastMiningPos) || (currentOre != -1 && lastSeenOreAmount != -1 && currentOre != lastSeenOreAmount)) {
                    lastMiningPos = pos.toImmutable();
                    lastSeenOreAmount = currentOre;
                    prevMiningProgress = 0.0f;
                    miningBarProgress = 0.0f;
                }
                lastSeenOreAmount = currentOre;

                prevMiningProgress = miningBarProgress;
                float delta = state.calcBlockBreakingDelta(client.player, client.world, pos);
                miningBarProgress += delta;
                if (miningBarProgress >= 1.0f) {
                    miningBarProgress = (block instanceof ResourceOreBlock) ? 0.0f : 1.0f;
                    prevMiningProgress = miningBarProgress;
                }
                return;
            }
        }

        prevMiningProgress = 0.0f;
        miningBarProgress = 0.0f;
        lastMiningPos = null;
        lastSeenOreAmount = -1;
    }

    private static void updateRadarEntities(World world, PlayerEntity player) {
        cachedRadarBlips.clear();
        int radiusBlocks = (MAP_CELLS / 2) * blocksPerCell;
        Box radarBox = player.getBoundingBox().expand(radiusBlocks, 24.0, radiusBlocks);
        List<Entity> entities = world.getOtherEntities(player, radarBox);

        for (Entity ent : entities) {
            int color = 0;
            if (ent instanceof Monster) color = 0xFFFF2222;
            else if (ent instanceof PlayerEntity) color = 0xFF44FF44;

            if (color != 0) {
                double dx = (ent.getX() - player.getX()) / blocksPerCell;
                double dz = (ent.getZ() - player.getZ()) / blocksPerCell;
                int ox = MathHelper.floor(dx * PIXEL_SCALE);
                int oz = MathHelper.floor(dz * PIXEL_SCALE);
                cachedRadarBlips.add(new RadarBlip(ox, oz, color));
            }
        }
    }

    private static void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.options.hudHidden || client.getDebugHud().shouldShowDebugHud()) {
            return;
        }

        int screenW = context.getScaledWindowWidth();
        int nextPanelY = 6;

        float mapScale = MathHelper.clamp(FactorioConfig.INSTANCE.minimapScale, 0.5f, 2.0f);
        context.getMatrices().push();
        context.getMatrices().translate(screenW, 0, 0);
        context.getMatrices().scale(mapScale, mapScale, 1.0f);
        context.getMatrices().translate(-screenW, 0, 0);

        int frameSize = MAP_SIZE_PX + 6;
        int x = screenW - frameSize - 6;
        int curTopY = 6;

        // 1. ПАНЕЛЬ ПРОГРЕССА ТЕХНОЛОГИИ НАД МИНИКАРТОЙ (как на скриншоте 205535.png!)
        int researchBarH = 22;
        renderTopRightResearchWidget(context, client.textRenderer, x, curTopY, frameSize, researchBarH);
        curTopY += researchBarH + 2;

        // 2. МИНИКАРТА ПОД ПАНЕЛЬЮ ИССЛЕДОВАНИЙ
        if (minimapVisible && FactorioConfig.INSTANCE.enableMinimap) {
            int y = curTopY;

            context.fill(x, y, x + frameSize, y + frameSize, 0xFF141414);
            context.fill(x + 1, y + 1, x + frameSize - 1, y + frameSize - 1, 0xFF313234);

            int mapX = x + 3;
            int mapY = y + 3;
            context.fill(mapX - 1, mapY - 1, mapX + MAP_SIZE_PX + 1, mapY + MAP_SIZE_PX + 1, 0xFF141414);

            for (int gz = 0; gz < MAP_CELLS; gz++) {
                int drawY = mapY + gz * PIXEL_SCALE;
                int rowOffset = gz * MAP_CELLS;
                for (int gx = 0; gx < MAP_CELLS; gx++) {
                    int drawX = mapX + gx * PIXEL_SCALE;
                    context.fill(drawX, drawY, drawX + PIXEL_SCALE, drawY + PIXEL_SCALE, colorBuffer[rowOffset + gx]);
                }
            }

            int centerPxX = mapX + MAP_SIZE_PX / 2;
            int centerPxY = mapY + MAP_SIZE_PX / 2;

            PollutionClientRenderer.renderMinimapPollutionOverlay(context, centerPxX, centerPxY, MAP_SIZE_PX / 2, (float) blocksPerCell / PIXEL_SCALE);

            for (RadarBlip blip : cachedRadarBlips) {
                int ex = centerPxX + blip.offsetX();
                int ez = centerPxY + blip.offsetZ();
                if (ex >= mapX + 2 && ex < mapX + MAP_SIZE_PX - 2 && ez >= mapY + 2 && ez < mapY + MAP_SIZE_PX - 2) {
                    context.fill(ex - 1, ez - 1, ex + 2, ez + 2, blip.color());
                }
            }

            drawPlayerMarker(context, centerPxX, centerPxY, client.player.getYaw());
            if (AltModeRenderer.isAltModeActive()) {
                context.fill(x - 28, y, x - 2, y + 14, 0xEE141414);
                context.fill(x - 27, y + 1, x - 3, y + 13, 0xEEAC6E14);
                context.drawText(client.textRenderer, "ALT", x - 23, y + 3, 0xFFFFFFFF, true);
            }
            curTopY += frameSize + 4;
        }

        context.getMatrices().pop();
        nextPanelY = (int) (6 + (curTopY - 6) * mapScale);

        // 3. ПРАВАЯ ИНФОРМАЦИОННАЯ ПАНЕЛЬ О ЦЕЛИ ПОД ПРИЦЕЛОМ
        if (FactorioConfig.INSTANCE.enableTargetInfoPanel) {
            float infoScale = MathHelper.clamp(FactorioConfig.INSTANCE.infoPanelScale, 0.5f, 2.0f);
            context.getMatrices().push();
            context.getMatrices().translate(screenW, nextPanelY, 0);
            context.getMatrices().scale(infoScale, infoScale, 1.0f);
            context.getMatrices().translate(-screenW, -nextPanelY, 0);

            renderTargetInfoPanel(context, client, screenW, nextPanelY);

            context.getMatrices().pop();
        }

        if (FactorioConfig.INSTANCE.enableCraftingQueueHud) {
            ClientCraftingQueueHud.renderBottomLeftQueue(context, false);
        }
        renderMiningProgressBar(context, tickCounter.getTickDelta(false));
    }

    /**
     * Отрисовывает блок активного исследования прямо над миникартой (как на скриншоте 205535.png).
     */
    private static void renderTopRightResearchWidget(DrawContext context, TextRenderer tr, int x, int y, int width, int height) {
        ResearchManager.init();
        ResearchManager.TechNode activeTech = ResearchManager.getActiveTech();

        context.fill(x, y, x + width, y + height, 0xFF141414);
        context.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xFF28292C);
        context.fill(x + 2, y + 2, x + width - 2, y + height - 2, 0xFF1F2023);

        if (activeTech == null) {
            String idleStr = "Нажмите [T] — Исследования";
            context.getMatrices().push();
            context.getMatrices().translate(x + 5, y + 8, 100.0f);
            context.getMatrices().scale(0.62f, 0.62f, 1.0f);
            context.drawText(tr, idleStr, 0, 0, 0xFF999B9F, true);
            context.getMatrices().pop();
            return;
        }

        // Иконка исследуемой технологии слева (16x16)
        context.getMatrices().push();
        context.getMatrices().translate(x + 3.0f, y + 3.0f, 100.0f);
        context.drawItem(activeTech.icon, 0, 0);
        context.getMatrices().pop();

        // Название технологии сверху справа от иконки
        float titleScale = 0.65f;
        int maxTitlePx = Math.round((width - 24) / titleScale);
        String trimmedTitle = tr.trimToWidth(activeTech.name, maxTitlePx);
        context.getMatrices().push();
        context.getMatrices().translate(x + 21.0f, y + 4.0f, 100.0f);
        context.getMatrices().scale(titleScale, titleScale, 1.0f);
        context.drawText(tr, trimmedTitle, 0, 0, 0xFFFFFFFF, true);
        context.getMatrices().pop();

        // Прогресс-бар снизу + процент справа (как на скриншоте 205535.png)
        float ratio = ResearchManager.getOverallProgressRatio();
        int pct = MathHelper.clamp(Math.round(ratio * 100.0f), 0, 100);
        String pctText = pct + "%";

        float pctScale = 0.62f;
        int pctW = Math.round(tr.getWidth(pctText) * pctScale);
        int pctX = x + width - pctW - 3;

        int barX = x + 21;
        int barY = y + 13;
        int barW = Math.max(16, (pctX - 3) - barX);
        int barH = 5;

        context.fill(barX, barY, barX + barW, barY + barH, 0xFF111213);
        context.fill(barX + 1, barY + 1, barX + barW - 1, barY + barH - 1, 0xFF2D2E32);

        int fillW = Math.round(ratio * (barW - 2));
        if (fillW > 0) {
            context.fill(barX + 1, barY + 1, barX + 1 + fillW, barY + barH - 1, 0xFF43A047);
            context.fill(barX + 1, barY + 1, barX + 1 + fillW, barY + 2, 0xFF66BB6A);
        }

        context.getMatrices().push();
        context.getMatrices().translate(pctX, y + 12.0f, 100.0f);
        context.getMatrices().scale(pctScale, pctScale, 1.0f);
        context.drawText(tr, pctText, 0, 0, 0xFFE6E6E6, true);
        context.getMatrices().pop();
    }

    private static class InfoSection {
        String title;
        int iconColor;
        List<Text> lines = new ArrayList<>();
        InfoSection(String t, int c) { title = t; iconColor = c; }
    }

    private static String localizeFluidKind(FactorioFluidContainer.FluidKind kind) {
        return switch (kind) {
            case WATER -> "Вода";
            case STEAM -> "Пар";
            case CRUDE_OIL -> "Сырая нефть";
            case PETROLEUM_GAS -> "Попутный нефтяной газ";
            default -> "Пусто";
        };
    }

    private static void renderTargetInfoPanel(DrawContext context, MinecraftClient client, int screenW, int topY) {
        if (!(client.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }
        World world = client.world;
        if (world == null) return;

        BlockPos rawPos = hit.getBlockPos();
        BlockState rawState = world.getBlockState(rawPos);
        if (rawState.isAir()) return;

        BlockPos pos = BlockHealthManager.getCanonicalPos(rawPos, rawState);
        BlockState state = world.getBlockState(pos);
        Block block = state.getBlock();

        int maxHp = BlockHealthManager.getMaxHealth(block);
        boolean isFactorioOre = block instanceof ResourceOreBlock || block instanceof OilMachines.CrudeOilDepositBlock;

        if (maxHp <= 0 && !isFactorioOre) {
            return;
        }

        Text title = block.getName();
        TextRenderer tr = client.textRenderer;
        FactorioConfig cfg = FactorioConfig.INSTANCE;

        List<InfoSection> sections = new ArrayList<>();
        List<Text> headerLines = new ArrayList<>();
        BlockEntity be = world.getBlockEntity(pos);

        // --- 1. Описание ---
        if (cfg.showInfoDescription) {
            String descKey = block.getTranslationKey() + ".desc";
            String desc = Text.translatable(descKey).getString();
            if (!desc.equals(descKey)) {
                String[] words = desc.split(" ");
                StringBuilder sb = new StringBuilder();
                for (String word : words) {
                    if (tr.getWidth(sb.toString() + word) > 180) {
                        headerLines.add(Text.literal(sb.toString()).formatted(Formatting.GRAY));
                        sb = new StringBuilder();
                    }
                    sb.append(word).append(" ");
                }
                if (sb.length() > 0) {
                    headerLines.add(Text.literal(sb.toString()).formatted(Formatting.GRAY));
                }
            }
        }

        // --- 2. Статус (и залежи руды/нефти) ---
        if (cfg.showInfoStatus) {
            if (block instanceof ResourceOreBlock oreBlock) {
                int amount = ResourceOreBlockEntity.getClientDisplayAmount(world, pos, oreBlock.getOreType());
                headerLines.add(Text.translatable("gui.factoriocore.info.expected_resources",
                                Text.literal(String.valueOf(amount)).formatted(Formatting.YELLOW))
                        .formatted(Formatting.WHITE));
            } else if (block instanceof OilMachines.CrudeOilDepositBlock) {
                int yieldPct = com.fixplot.factoriocore.worldgen.NauvisChunkGenerator.evaluateOilYieldPercentAt(pos.getX(), pos.getZ());
                headerLines.add(Text.literal("Дебит скважины: ").formatted(Formatting.WHITE)
                        .append(Text.literal(yieldPct + "%").formatted(Formatting.LIGHT_PURPLE)));
            } else if (be != null && !(be instanceof PipeBlockEntity)) {
                boolean isWorking = false;
                boolean noFuel = false;
                boolean noPower = false;

                if (be instanceof ElectricDrillBlockEntity eDrill) {
                    isWorking = eDrill.isActivelyMining();
                    noPower = !eDrill.isPowered();
                } else if (be instanceof BoilerBlockEntity boiler) {
                    isWorking = boiler.isBurning();
                    noFuel = !isWorking && boiler.getStack(0).isEmpty();
                } else if (be instanceof BurnerDrillBlockEntity drill) {
                    isWorking = drill.getClientDrillRotation(0.0f) > 0.0f || !drill.getFuelStack().isEmpty();
                    noFuel = !isWorking;
                } else if (be instanceof FactorioFurnaceBlockEntity furnace) {
                    isWorking = furnace.isBurning();
                    noFuel = !isWorking && furnace.getStack(1).isEmpty();
                } else if (be instanceof InserterBlockEntity ins) {
                    boolean isBurner = block instanceof BurnerInserterBlock;
                    isWorking = !ins.getHeldStack().isEmpty() || ins.getArmProgress(0.0f) > 0.01f;
                    boolean powered = isBurner || PowerNetworkManager.isMachinePowered(world, pos);
                    noPower = !isBurner && !powered;
                    noFuel = isBurner && ins.getFuelStack().isEmpty();
                } else if (be instanceof com.fixplot.factoriocore.content.research.LabBlockEntity lab) {
                    isWorking = lab.isWorking();
                    noPower = !lab.isPowered();
                } else if (be instanceof AssemblerBlockEntity asm) {
                    isWorking = asm.isWorking();
                    noPower = !asm.isPowered();
                } else if (be instanceof OilMachines.PumpjackBlockEntity pj) {
                    isWorking = pj.isWorking();
                    noPower = !pj.isPowered();
                } else if (be instanceof OilMachines.OilRefineryBlockEntity ref) {
                    isWorking = ref.isWorking();
                    noPower = !ref.isPowered();
                } else if (be instanceof OilMachines.ChemicalPlantBlockEntity cp) {
                    isWorking = cp.isWorking();
                    noPower = !cp.isPowered();
                } else if (block instanceof com.fixplot.factoriocore.content.electricity.ElectricPoleBlock) {
                    isWorking = PowerNetworkManager.isPoleEnergized(world, pos);
                    noPower = !isWorking;
                }

                if (noPower) {
                    headerLines.add(Text.translatable("gui.factoriocore.info.status_no_power").formatted(Formatting.RED));
                } else if (noFuel) {
                    headerLines.add(Text.translatable("gui.factoriocore.info.status_no_fuel").formatted(Formatting.RED));
                } else if (isWorking) {
                    headerLines.add(Text.translatable("gui.factoriocore.info.status_working").formatted(Formatting.GREEN));
                } else {
                    headerLines.add(Text.translatable("gui.factoriocore.info.status_waiting").formatted(Formatting.YELLOW));
                }
            }
        }

        // --- 3. СОДЕРЖИМОЕ ТРУБ И ЖИДКОСТНЫХ МАШИН ---
        if (cfg.showInfoFluids) {
            if (be instanceof PipeBlockEntity pipe) {
                FactorioFluidContainer.FluidKind kind = pipe.getFluidKind();
                int amt = pipe.getFluidAmount();
                int cap = pipe.getFluidCapacity();
                InfoSection pipeSec = new InfoSection("Содержимое трубопровода", kind.color);
                if (amt <= 0 || kind == FactorioFluidContainer.FluidKind.NONE) {
                    pipeSec.lines.add(Text.literal("Жидкость: Пусто (0 / " + cap + " мБ)").formatted(Formatting.GRAY));
                } else {
                    pipeSec.lines.add(Text.literal(localizeFluidKind(kind) + ": ").formatted(Formatting.WHITE)
                            .append(Text.literal(amt + " / " + cap + " мБ").formatted(Formatting.AQUA)));
                    pipeSec.lines.add(Text.translatable("gui.factoriocore.info.temperature", pipe.getTemperatureC() + " °C").formatted(Formatting.WHITE));
                }
                sections.add(pipeSec);
            } else if (be instanceof OffshorePumpBlockEntity) {
                InfoSection pumpSec = new InfoSection("Выход жидкости", 0x2980B9);
                pumpSec.lines.add(Text.literal("Вода: 1200 мБ/с (15 °C)").formatted(Formatting.AQUA));
                sections.add(pumpSec);
            } else if (be instanceof BoilerBlockEntity boiler) {
                InfoSection waterSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_water").getString(), 0x33CCFF);
                waterSec.lines.add(Text.translatable("gui.factoriocore.info.water_line", boiler.getWaterMb()).formatted(Formatting.WHITE));
                waterSec.lines.add(Text.translatable("gui.factoriocore.info.temperature", "15 °C").formatted(Formatting.WHITE));
                sections.add(waterSec);

                InfoSection steamSec = new InfoSection(Text.translatable("gui.factoriocore.info.produces_steam").getString(), 0xDDDDDD);
                steamSec.lines.add(Text.literal("Пар: " + boiler.getSteamMb() + " / 2000 мБ (165 °C)").formatted(Formatting.WHITE));
                sections.add(steamSec);
            } else if (be instanceof SteamEngineBlockEntity engine) {
                InfoSection steamSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_steam").getString(), 0xDDDDDD);
                steamSec.lines.add(Text.translatable("gui.factoriocore.info.steam_line", engine.getFluidAmount()).formatted(Formatting.WHITE));
                steamSec.lines.add(Text.translatable("gui.factoriocore.info.max_temperature", "165 °C").formatted(Formatting.WHITE));
                sections.add(steamSec);
            } else if (be instanceof OilMachines.PumpjackBlockEntity pj) {
                InfoSection oilSec = new InfoSection("Добыча сырой нефти", 0x33333A);
                oilSec.lines.add(Text.literal("Сырая нефть: " + pj.getFluidAmount() + " / 2000 мБ").formatted(Formatting.WHITE));
                sections.add(oilSec);
            } else if (be instanceof OilMachines.OilRefineryBlockEntity ref) {
                InfoSection refSec = new InfoSection("Жидкости НПЗ", 0x9B59B6);
                refSec.lines.add(Text.literal("Сырая нефть (Вход): " + ref.getCrudeOilMb() + " / 4000 мБ").formatted(Formatting.WHITE));
                if (ref.getRecipeMode() >= 1 || ref.getWaterMb() > 0) {
                    refSec.lines.add(Text.literal("Вода (Вход): " + ref.getWaterMb() + " / 4000 мБ").formatted(Formatting.AQUA));
                }
                refSec.lines.add(Text.literal("Попутный газ (Выход): " + ref.getPetroleumGasMb() + " / 4000 мБ").formatted(Formatting.LIGHT_PURPLE));
                sections.add(refSec);
            } else if (be instanceof OilMachines.ChemicalPlantBlockEntity cp) {
                InfoSection cpSec = new InfoSection("Жидкости Химзавода", 0x9B59B6);
                cpSec.lines.add(Text.literal("Попутный газ (Вход): " + cp.getPetroleumGasMb() + " / 4000 мБ").formatted(Formatting.LIGHT_PURPLE));
                if (cp.getRecipeMode() == 1 || cp.getWaterMb() > 0) {
                    cpSec.lines.add(Text.literal("Вода (Вход): " + cp.getWaterMb() + " / 4000 мБ").formatted(Formatting.AQUA));
                }
                sections.add(cpSec);
            }
        }

        // --- 4. Электричество / Топливо ---
        if (cfg.showInfoElectricity) {
            if (block instanceof ElectricDrillBlock || be instanceof OilMachines.PumpjackBlockEntity) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(90_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof OilMachines.OilRefineryBlockEntity) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(420_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof OilMachines.ChemicalPlantBlockEntity) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(210_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof com.fixplot.factoriocore.content.research.LabBlockEntity) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(60_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof AssemblerBlockEntity) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(75_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof SteamEngineBlockEntity engine) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.produces_electricity").getString(), 0xFFD700);
                String kw = PowerNetworkManager.formatWatts(engine.isGeneratingPower() ? 900_000L : 0L);
                String maxKw = PowerNetworkManager.formatWatts(900_000L);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.energy_production", kw + " / " + maxKw).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (be instanceof BoilerBlockEntity) {
                InfoSection fuelSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_fuel").getString(), 0xFF8C00);
                fuelSec.lines.add(Text.translatable("gui.factoriocore.info.max_consumption", PowerNetworkManager.formatWatts(1_800_000L)).formatted(Formatting.WHITE));
                sections.add(fuelSec);
            } else if (be instanceof InserterBlockEntity ins && !(block instanceof BurnerInserterBlock)) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.consumes_electricity").getString(), 0xFFD700);
                boolean active = !ins.getHeldStack().isEmpty() || ins.getArmProgress(0.0f) > 0.01f;
                String usage = PowerNetworkManager.formatWatts(active ? 13_000L : 400L);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.consumption", usage).formatted(Formatting.WHITE));
                sections.add(elecSec);
            } else if (block instanceof com.fixplot.factoriocore.content.electricity.CreativeEnergySourceBlock) {
                InfoSection elecSec = new InfoSection(Text.translatable("gui.factoriocore.info.produces_electricity").getString(), 0xFFD700);
                elecSec.lines.add(Text.translatable("gui.factoriocore.info.energy_production", PowerNetworkManager.formatWatts(500_000_000L)).formatted(Formatting.WHITE));
                sections.add(elecSec);
            }
        }

        // --- 5. Сундуки ---
        List<ItemStack> chestTopItems = Collections.emptyList();
        if (block instanceof FactorioChestBlock && be instanceof FactorioChestBlockEntity chest) {
            chestTopItems = chest.getSortedContentSummary(4);
            if (chest.getUnlockedSlots() < chest.getTotalSlots()) {
                headerLines.add(Text.translatable("gui.factoriocore.info.slots_available",
                                Text.literal(chest.getUnlockedSlots() + " / " + chest.getTotalSlots()).formatted(Formatting.RED))
                        .formatted(Formatting.WHITE));
            }
        }

        int panelW = Math.max(160, tr.getWidth(title) + 40);
        for (Text line : headerLines) panelW = Math.max(panelW, tr.getWidth(line) + 16);
        for (InfoSection sec : sections) {
            panelW = Math.max(panelW, tr.getWidth(sec.title) + 24);
            for (Text line : sec.lines) panelW = Math.max(panelW, tr.getWidth(line) + 16);
        }
        if (!chestTopItems.isEmpty()) panelW = Math.max(panelW, chestTopItems.size() * 20 + 16);

        int hpBarH = (cfg.showInfoHealth && maxHp > 0) ? 14 : 0;
        int chestIconsH = chestTopItems.isEmpty() ? 0 : 22;
        int panelH = 26 + headerLines.size() * 11 + hpBarH + chestIconsH + 4;
        for (InfoSection sec : sections) {
            panelH += 18 + sec.lines.size() * 11 + 4;
        }

        int x = screenW - panelW - 6;
        int y = topY;

        context.fill(x, y, x + panelW, y + panelH, 0xFA1E1E1E);
        context.fill(x + 1, y + 1, x + panelW - 1, y + panelH - 1, 0xFA2C2C2C);
        context.fill(x + 2, y + 2, x + panelW - 2, y + 22, 0xFFE2C899);
        context.fill(x + 2, y + 22, x + panelW - 2, y + 24, 0xFF000000);

        ItemStack iconStack = new ItemStack(block.asItem());
        if (!iconStack.isEmpty()) {
            context.drawItem(iconStack, x + 4, y + 4);
        }
        context.drawText(tr, title, x + 24, y + 8, 0xFF000000, false);

        int cursorY = y + 28;
        for (Text line : headerLines) {
            context.drawText(tr, line, x + 8, cursorY, 0xFFFFFFFF, false);
            cursorY += 11;
        }

        if (cfg.showInfoHealth && maxHp > 0) {
            int curHp = BlockHealthManager.getCurrentHealth(world, pos, state);
            float ratio = MathHelper.clamp(curHp / (float) maxHp, 0.0f, 1.0f);
            context.drawText(tr, Text.translatable("gui.factoriocore.info.health", curHp + "/" + maxHp).formatted(Formatting.WHITE), x + 8, cursorY, 0xFFFFFFFF, false);
            cursorY += 10;
            int barX = x + 8;
            int barW = panelW - 16;
            int barH = 4;
            context.fill(barX, cursorY, barX + barW, cursorY + barH, 0xFF141414);
            int fillW = Math.round(ratio * barW);
            int barColor = (ratio > 0.6f) ? 0xFF38B828 : (ratio > 0.3f ? 0xFFE59524 : 0xFFD93025);
            if (fillW > 0) context.fill(barX, cursorY, barX + fillW, cursorY + barH, barColor);
            cursorY += 8;
        }

        for (InfoSection sec : sections) {
            context.fill(x + 4, cursorY, x + panelW - 4, cursorY + 1, 0xFF444444);
            cursorY += 4;
            context.fill(x + 8, cursorY + 2, x + 12, cursorY + 6, 0xFF000000 | sec.iconColor);
            context.drawText(tr, Text.literal(sec.title).formatted(Formatting.YELLOW), x + 16, cursorY, 0xFFFFFFFF, false);
            cursorY += 12;
            context.fill(x + 4, cursorY, x + panelW - 4, cursorY + 1, 0xFF333333);
            cursorY += 4;
            for (Text line : sec.lines) {
                context.drawText(tr, line, x + 8, cursorY, 0xFFFFFFFF, false);
                cursorY += 11;
            }
        }

        if (!chestTopItems.isEmpty()) {
            cursorY += 2;
            int slotStartX = x + 8;
            for (int i = 0; i < chestTopItems.size(); i++) {
                ItemStack st = chestTopItems.get(i);
                int sx = slotStartX + i * 20;
                int sy = cursorY;
                context.fill(sx, sy, sx + 18, sy + 18, 0xFF141414);
                context.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF3A3C3E);
                context.drawItem(st, sx + 1, sy + 1);

                String cntStr = formatCompactCount(st.getCount());
                context.getMatrices().push();
                context.getMatrices().translate(0.0f, 0.0f, 200.0f);
                context.getMatrices().scale(0.65f, 0.65f, 1.0f);
                int tw = tr.getWidth(cntStr);
                int tx = (int) ((sx + 17) / 0.65f) - tw;
                int ty = (int) ((sy + 12) / 0.65f);
                context.drawText(tr, cntStr, tx, ty, 0xFFFFFFFF, true);
                context.getMatrices().pop();
            }
        }
    }

    private static String formatCompactCount(int count) {
        if (count >= 1000) return String.format("%.1fk", count / 1000.0f);
        return String.valueOf(count);
    }

    private static void renderMiningProgressBar(DrawContext context, float tickDelta) {
        if (miningBarProgress <= 0.0f && prevMiningProgress <= 0.0f) return;

        float smoothProgress = MathHelper.clamp(MathHelper.lerp(tickDelta, prevMiningProgress, miningBarProgress), 0.0f, 1.0f);
        int screenW = context.getScaledWindowWidth();
        int screenH = context.getScaledWindowHeight();
        int barW = 182;
        int barH = 5;
        int bx = (screenW - barW) / 2;
        int by = screenH - 54;

        context.fill(bx - 1, by - 1, bx + barW + 1, by + barH + 1, 0xEE141414);
        context.fill(bx, by, bx + barW, by + barH, 0xEE26272A);
        int fillW = Math.round(smoothProgress * barW);
        if (fillW > 0) {
            context.fill(bx, by, bx + fillW, by + barH, 0xFFE59524);
            context.fill(bx, by, bx + fillW, by + 2, 0xFFFFCC66);
        }
    }

    private static void drawPlayerMarker(DrawContext context, int cx, int cy, float yaw) {
        context.fill(cx - 2, cy - 2, cx + 3, cy + 3, 0xFF111111);
        context.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFCC00);

        double rad = Math.toRadians(yaw + 90.0f);
        int tipX = cx + (int) Math.round(Math.cos(rad) * 3.0);
        int tipY = cy + (int) Math.round(Math.sin(rad) * 3.0);
        context.fill(tipX - 1, tipY - 1, tipX + 1, tipY + 1, 0xFFFFFFFF);
    }

    private static void updateMapSlice(World world, PlayerEntity player, int startRow, int endRow) {
        int centerX = MathHelper.floor(player.getX());
        int centerZ = MathHelper.floor(player.getZ());
        int half = MAP_CELLS / 2;
        BlockPos.Mutable pos = new BlockPos.Mutable();

        int maxRow = Math.min(MAP_CELLS, endRow);
        for (int gz = startRow; gz < maxRow; gz++) {
            int wz = centerZ + (gz - half) * blocksPerCell;
            int rowOffset = gz * MAP_CELLS;

            for (int gx = 0; gx < MAP_CELLS; gx++) {
                int wx = centerX + (gx - half) * blocksPerCell;

                if (!world.isChunkLoaded(wx >> 4, wz >> 4)) {
                    colorBuffer[rowOffset + gx] = 0xFF18191B;
                    continue;
                }

                int topY = world.getTopY(Heightmap.Type.WORLD_SURFACE, wx, wz) - 1;
                if (topY < world.getBottomY()) {
                    colorBuffer[rowOffset + gx] = 0xFF18191B;
                    continue;
                }

                pos.set(wx, topY, wz);
                BlockState state = world.getBlockState(pos);
                if (state.isAir() && topY > world.getBottomY()) {
                    pos.set(wx, topY - 1, wz);
                    state = world.getBlockState(pos);
                }

                colorBuffer[rowOffset + gx] = resolveFactorioMapColor(world, pos, state);
            }
        }
    }

    private static int resolveFactorioMapColor(World world, BlockPos pos, BlockState state) {
        Block block = state.getBlock();

        if (block instanceof OilMachines.CrudeOilDepositBlock
                || com.fixplot.factoriocore.worldgen.NauvisChunkGenerator.hasCrudeOilSpotAt(pos.getX(), pos.getZ(), 0.25)) {
            return 0xFFD81B60; // Фирменный пурпурный цвет нефти на карте Factorio!
        }

        if (state.isOf(Blocks.WATER) || state.isOf(Blocks.SEAGRASS) || state.isOf(Blocks.LILY_PAD)) {
            float factor = com.fixplot.factoriocore.content.pollution.PollutionManager.getClientWaterTintFactor(pos.getX(), pos.getZ());
            if (factor <= 0.01f) return 0xFF2471A3;
            int r = MathHelper.lerp(factor, 0x24, 0x46);
            int g = MathHelper.lerp(factor, 0x71, 0x6E);
            int b = MathHelper.lerp(factor, 0xA3, 0x24);
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }

        if (block instanceof BeltBlock belt) {
            return switch (belt.getTier()) {
                case 2 -> 0xFFE53935;
                case 3 -> 0xFF29B6F6;
                default -> 0xFFFDD835;
            };
        }
        if (block instanceof com.fixplot.factoriocore.content.production.burner_drill.BurnerDrillBlock || block instanceof FactorioFurnaceBlock) return 0xFF42A5F5;
        if (block instanceof InserterBlock || block instanceof FactorioChestBlock) return 0xFFFFB300;
        if (block instanceof OilMachines.CrudeOilDepositBlock) return 0xFFD81B60; // Пурпурные точки нефти на миникарте как в Factorio!

        if (block instanceof ResourceOreBlock ore) {
            return switch (ore.getOreType()) {
                case 0 -> 0xFF5B9BD5;
                case 1 -> 0xFFED7D31;
                case 2 -> 0xFF1A1A1D;
                default -> 0xFFD2C290;
            };
        }

        Block below = world.getBlockState(pos.down()).getBlock();
        if (below instanceof ResourceOreBlock oreBelow) {
            return switch (oreBelow.getOreType()) {
                case 0 -> 0xFF5B9BD5;
                case 1 -> 0xFFED7D31;
                case 2 -> 0xFF1A1A1D;
                default -> 0xFFD2C290;
            };
        }

        if (block instanceof PavementBlock) return 0xFF70757A;
        if (pos.getY() >= 66 && (state.isOf(Blocks.DRIPSTONE_BLOCK) || state.isOf(Blocks.GRANITE) || state.isOf(Blocks.TUFF))) return 0xFF424949;

        MapColor mapColor = state.getMapColor(world, pos);
        if (mapColor == MapColor.CLEAR) {
            BlockState groundState = world.getBlockState(pos.down());
            mapColor = groundState.getMapColor(world, pos.down());
        }
        int rgb = mapColor.color;
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}